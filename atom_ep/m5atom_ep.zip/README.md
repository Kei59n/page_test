# summer_school
- 夏休み子供工作教室の課題だった
- 「夏休み作り方.pdf」 は工作教室で配布した説明書
- 工作教室は専用基板なのでハードウエアの説明は参考まで。

# 測定回路
- ホール素子を内蔵した磁気センサIC。[RSコンポーネンツ](https://jp.rs-online.com/web/p/motion-sensor-ics/9009772?gb=s)で販売している。
- アナログ出力の磁気センサICなら多分どれでも使える
- コネクタはGrove用を[秋月](https://akizukidenshi.com/catalog/g/g112634/)で購入した
- 通常I2Cのセンサモジュールを接続するGroveコネクタをアナログ入力に設定して使用
![回路図](https://github.com/Kei59n/summer_school/blob/images/sensor.jpg)

# 使用法
- 磁気センサを平行ビニール線の中央部に押しつけて固定する
- M5AtomにUSBケーブルを接続する
- M5AtomがWiFiステーションになるので、M5AtomPWR を探して接続する（パスワードなし）
- http://192.168.4.1 をブラウザで開くとグラフが表示される
![使用法](https://github.com/Kei59n/summer_school/blob/images/snap_shot.jpg)
![画面](https://github.com/Kei59n/summer_school/blob/images/graph.png)
# 開発環境
### Arduino IDE
- 旧バージョンの ArduinoIED 1.8.19 を使用した
- 最新の環境では後述する ESP32 Sketch Data Uploader ツールが使えない
- [この辺](https://dmspace.tsuchida.ne.jp/2022/04/01/210/)を参考に環境を設定する
### ESP32 Sketch Data Uploader
- ESP32のフラッシュメモリをファイルシステムとして使う
- data ディレクトリの内容をファイルシステムに転送するツール
- webサーバーが使うファイル index.html, Chart.min.js をファイルシステムに転送する
- [この辺](https://it-style.jp/?p=834)を参考にしてインストール